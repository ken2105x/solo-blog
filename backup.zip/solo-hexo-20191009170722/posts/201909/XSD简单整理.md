title: XSD简单整理
date: '2019-09-20 14:06:24'
updated: '2019-09-30 16:33:07'
tags: [xml]
permalink: /articles/2019/09/20/1568959584768.html
---
## 引言
在使用spring或者maven进行配置时，经常会使用xml文件来作为配置，但是xml头上那块东西到底是什么，一直没弄明白，今天搜索了下资料，大概做一下整理

## XSD 简介
XML Schema 的作用是定义 XML 文档的合法构建模块，类似 DTD。  
XML Schema:
- 定义可出现在文档中的元素
- 定义可出现在文档中的属性
- 定义哪个元素是子元素
- 定义子元素的次序
- 定义子元素的数目
- 定义元素是否为空，或者是否可包含文本
- 定义元素和属性的数据类型
- 定义元素和属性的默认值以及固定值

## XSD 为何使用
XML Schema 最重要的能力之一就是对数据类型的支持。  
通过对数据类型的支持：
- 可更容易地描述允许的文档内容
- 可更容易地验证数据的正确性
- 可更容易地与来自数据库的数据一并工作
- 可更容易地定义数据约束（data facets）
- 可更容易地定义数据模型（或称数据格式）
- 可更容易地在不同的数据类型间转换数据


## 代码解释
先看一段pom.xml的引用
```
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans
                           http://www.springframework.org/schema/beans/spring-beans.xsd">
```

**说明：**
```
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
```
显示 schema 中用到的元素和数据类型来自命名空间 "http://www.w3.org/2001/XMLSchema-instance"。同时它还规定了来自命名空间 "http://www.w3.org/2001/XMLSchema-instance" 的元素和数据类型应该使用前缀 xsi

---

```
xmlns="http://www.springframework.org/schema/beans"
```
指出默认的命名空间是 "http://www.springframework.org/schema/beans"。

---

```
 xsi:schemaLocation="http://www.springframework.org/schema/beans
                           http://www.springframework.org/schema/beans/spring-beans.xsd"http://www.springframework.org/schema/beans/spring-beans.xsd"
```
一旦您拥有了可用的 XML Schema 实例命名空间：
您就可以使用 schemaLocation 属性了。此属性有两个值。第一个值是需要使用的命名空间。第二个值是供命名空间使用的 XML schema 的位置。

---
该xml需要遵从"http://www.springframework.org/schema/beans/spring-beans.xsd"的配置进行书写，详细规范格式尚未去了解，未完待续。
