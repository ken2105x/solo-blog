title: 类加载器ClassLoader
date: '2019-09-19 16:49:20'
updated: '2019-09-19 17:05:07'
tags: [java]
permalink: /articles/2019/09/19/1568882960111.html
---
## 类加载器概述
&emsp;主要的作用是将class文件加载到jvm虚拟机中。jvm启动的时候，并不是一次性加载所有的类，而是根据需要动态去加载类，主要分为隐式加载和显示加载。

1. **隐式加载：**  
程序代码中不通过调用ClassLoader来加载需要的类，而是通过JVM类自动加载需要的类到内存中。例如，当我们在类中继承或者引用某个类的时候，JVM在解析当前这个类的时，发现引用的类不在内存中，那么就会自动将这些类加载到内存中。

2. **显示加载：**  
代码中通过Class.forName（），this.getClass.getClassLoader.LoadClass（），自定义类加载器中的findClass（）方法等。

## 加载机制
### Java默认提供的三个ClassLoader  
1. BootStrap ClassLoader：  
主要加载%JRE_HOME%\lib下的rt.jar、resources.jar、charsets.jar和class等。   
可以通过System.getProperty("sun.boot.class.path")查看加载路径
2. EtxClassLoader  
主要加载目录%JRE_HOME%\lib\ext目录下的jar包和class文件。  
可以通过System.out.println(System.getProperty("java.ext.dirs"))查看加载路径
3. AppClassLoader
主要加载当前应用下的classpath路径下的类。之前我们在环境变量中配置的classpath就是指定AppClassLoader的类加载路径。

### 类加载器的继承关系
![image](http://ken2105.gitee.io/picture/solo/classloader/1.png)

### 双亲委派模式
![image](http://ken2105.gitee.io/picture/solo/classloader/2.png) 

双亲委派模式指 ClassLoader会先交由父加载器加载，由上而下依次检查，如最后自己也找不到类，则抛出ClassNotFoundException异常

### 双亲委派的好处
带有层级关系，可避免重复加载

### 自定义类加载器
当class文件不在上述加载器的目录范围内是，则使用自定义加载器
```
package test;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class MyClassLoader extends ClassLoader{

    private String classpath;
    
    public MyClassLoader(String classpath) {
        
        this.classpath = classpath;
    }

    @Override
    protected Class<?> findClass(String name) throws ClassNotFoundException {
        try {
            byte [] classDate=getDate(name);
            
            if(classDate==null){}
            
            else{
                //defineClass方法将字节码转化为类
                return defineClass(name,classDate,0,classDate.length);
            }
            
        } catch (IOException e) {
            
            e.printStackTrace();
        }
        
        return super.findClass(name);
    }
    //返回类的字节码
    private byte[] getDate(String className) throws IOException{
        InputStream in = null;
        ByteArrayOutputStream out = null;
        String path=classpath + File.separatorChar +
                    className.replace('.',File.separatorChar)+".class";
        try {
            in=new FileInputStream(path);
            out=new ByteArrayOutputStream();
            byte[] buffer=new byte[2048];
            int len=0;
            while((len=in.read(buffer))!=-1){
                out.write(buffer,0,len);
            }
            return out.toByteArray();
        } 
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        finally{
            in.close();
            out.close();
        }
        return null;
    }
}
```
